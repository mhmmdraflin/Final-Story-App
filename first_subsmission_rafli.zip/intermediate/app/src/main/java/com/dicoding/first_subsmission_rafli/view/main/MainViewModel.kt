package com.dicoding.first_subsmission_rafli.view.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.dicoding.first_subsmission_rafli.data.preference.StoryModel
import com.dicoding.first_subsmission_rafli.repository.StoryRepository
import kotlinx.coroutines.launch

class MainViewModel (private val repository: StoryRepository) : ViewModel() {
    fun getSession(): LiveData<StoryModel> {
        return repository.getSession().asLiveData()
    }

    fun getStories() = repository.getStory()

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

}